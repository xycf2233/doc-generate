package com.xycf.generate.common.base;

public interface AbstractExceptionEnum {
    String getErrorCode();

    String getUserTip();
}
