package com.xycf.generate.service.base;

/**
 * @Author ztc
 * @Description 解析xml的服务层
 * @Date 2023/2/10 10:04
 */
public interface XmlService {


    void parseWordXml(String path);
}
