# doc-generate
## 约定字段描述

---
${interfaceAddress}  接口地址  
${method} 请求方式  
${request} 入参示例json格式  
${response} 出参示例json格式  
${title}  接口名称  
---
### 入参：
${in-paramName} 参数名  
${in-type} 类型  
${in-isMust} 是否必须  
${in-description} 描述  
${in-remarks} 备注  用来标识query/path/body/form  
---
### 出参
${out-paramName} 参数名  
${out-type} 类型  
${out-isMust} 是否必须  
${out-description} 描述  
.....待补充