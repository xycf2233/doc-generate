# doc-generate
## 约定字段描述

---
«${interfaceAddress}»  接口地址  
«${method}» 请求方式  
«${requestBody}» 入参示例json格式  
«${responseBody}» 出参示例json格式  
«${title}»  接口名称  
---
### 入参：
«${requestParam.name}» 参数名  
«${requestParam.type}» 类型  
«${requestParam.isMust}» 是否必须  
«${requestParam.defaultValue}» 默认值  
«${requestParam.remarks}» 备注  用来标识query/path/body/form  
---
### 出参
«${responseParam.name}» 参数名  
«${responseParam.type}» 类型  
«${responseParam.remarks}» 描述  
.....待补充