package com.xycf.generate.service;

import com.xycf.generate.service.base.DocService;

/**
 * @Author ztc
 * @Description word文档处理类
 * @Date 2023/1/31 15:29
 */
public interface WordService extends DocService {
}
